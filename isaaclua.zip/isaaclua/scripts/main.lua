-- main.lua - prelude de isaaclua (escrito desde cero, API compatible con la de Isaac).
-- Lo ejecuta isaaclua_boot() ANTES de cargar los mods. Devuelve una tabla
-- con las funciones que el codigo C necesita (dispatch, msgh, begin_mod, end_mod).

local native = __il   -- tabla de funciones nativas; se oculta de los mods
__il = nil

-- Referencias que los mods no deben poder tocar ------------------------------
local traceback    = debug.traceback
local loadfile_raw = loadfile
local xpcall, type, tostring, select, error = xpcall, type, tostring, select, error
local tconcat = table.concat
local os_time, os_date, os_clock, os_difftime = os.time, os.date, os.clock, os.difftime

-- Sandbox: sin io, sin ejecutar procesos, sin cargar codigo nativo -------------
io, dofile, loadfile = nil, nil, nil
os = { time = os_time, date = os_date, clock = os_clock, difftime = os_difftime }
debug = { traceback = traceback, getinfo = debug.getinfo }
package.loadlib = nil
package.cpath = ""
package.path = ""
package.searchers = { package.searchers[1], package.searchers[2] } -- solo Lua

local log = native.log

-- print va al log, como en el juego -------------------------------------------
function print(...)
    local n = select("#", ...)
    local t = {}
    for i = 1, n do t[i] = tostring((select(i, ...))) end
    log(tconcat(t, "\t"))
end

local function msgh(m) return traceback(tostring(m), 2) end

-- Registro de callbacks (copy-on-write: modificar durante un despacho es seguro)
local registry = {}   -- [callbackId] = { {mod=,fn=,param=,priority=}, ... }
local err_count = {}

local function mod_name(mod)
    return (type(mod) == "table" and mod.Name) or "?"
end

local function add_callback(mod, cb, fn, param, priority)
    if type(cb) ~= "number" then error("AddCallback: id de callback invalido", 3) end
    if type(fn) ~= "function" then error("AddCallback: la funcion es invalida", 3) end
    priority = priority or 0
    local old, new = registry[cb] or {}, {}
    local entry = { mod = mod, fn = fn, param = param, priority = priority }
    local placed = false
    for i = 1, #old do
        if not placed and priority < old[i].priority then
            new[#new + 1] = entry
            placed = true
        end
        new[#new + 1] = old[i]
    end
    if not placed then new[#new + 1] = entry end
    registry[cb] = new
end

local function remove_callback(mod, cb, fn)
    local old = registry[cb]
    if not old then return end
    local new = {}
    for i = 1, #old do
        local e = old[i]
        if e.mod == mod and e.fn == fn then e.removed = true else new[#new + 1] = e end
    end
    registry[cb] = new
end

local function report_error(e, cb, msg)
    local first = tostring(msg):match("^[^\n]*") or "?"
    local key = mod_name(e.mod) .. "|" .. cb .. "|" .. first
    local c = (err_count[key] or 0) + 1
    err_count[key] = c
    if c <= 3 then
        log("[Lua] error en mod '" .. mod_name(e.mod) .. "' (callback " .. cb .. "):\n" .. tostring(msg))
    elseif c == 4 then
        log("[Lua] (se omiten los siguientes errores iguales de '" .. mod_name(e.mod) .. "')")
    end
end

local function dispatch(cb, param, stop, ...)
    local list = registry[cb]
    if not list then return nil end
    for i = 1, #list do
        local e = list[i]
        if not e.removed and (e.param == nil or e.param == param) then
            local ok, r = xpcall(e.fn, msgh, e.mod, ...)
            if ok then
                if stop and r ~= nil then return r end
            else
                report_error(e, cb, r)
            end
        end
    end
    return nil
end

-- API Isaac.* -----------------------------------------------------------------
Isaac = {}
function Isaac.DebugString(s)     log("[Lua] " .. tostring(s)) end
function Isaac.ConsoleOutput(s)   log("[Lua] " .. tostring(s)) end
Isaac.GetFrameCount = native.frame_count
Isaac.GetTime       = native.time

function Isaac.AddCallback(mod, cb, fn, param) add_callback(mod, cb, fn, param, 0) end
function Isaac.AddPriorityCallback(mod, cb, priority, fn, param)
    add_callback(mod, cb, fn, param, priority)
end
Isaac.RemoveCallback = remove_callback

local function data_name(mod)
    if type(mod) ~= "table" or type(mod.Name) ~= "string" then
        error("el mod no es valido (usa RegisterMod)", 3)
    end
    return mod.Name
end
function Isaac.SaveModData(mod, data)
    if type(data) ~= "string" then error("SaveData espera un string", 3) end
    return native.save(data_name(mod), data)
end
function Isaac.LoadModData(mod)   return native.load(data_name(mod)) end
function Isaac.HasModData(mod)    return native.has(data_name(mod)) end
function Isaac.RemoveModData(mod) return native.remove(data_name(mod)) end

-- Game(): por ahora solo lo minimo (stub). Se amplia con los bindings en C.
local game_stub = { GetFrameCount = function() return native.frame_count() end }
function Game() return game_stub end

-- RegisterMod: devuelve la tabla del mod con la misma interfaz que el juego ---
function RegisterMod(name, apiversion)
    if type(name) ~= "string" then error("RegisterMod: el nombre debe ser texto", 2) end
    if apiversion ~= 1 then log("[Lua] aviso: '" .. name .. "' usa apiversion " .. tostring(apiversion)) end
    local mod = { Name = name }
    function mod:AddCallback(cb, fn, param) Isaac.AddCallback(self, cb, fn, param) end
    function mod:AddPriorityCallback(cb, priority, fn, param)
        Isaac.AddPriorityCallback(self, cb, priority, fn, param)
    end
    function mod:RemoveCallback(cb, fn) Isaac.RemoveCallback(self, cb, fn) end
    function mod:SaveData(data) return Isaac.SaveModData(self, data) end
    function mod:LoadData()     return Isaac.LoadModData(self) end
    function mod:HasData()      return Isaac.HasModData(self) end
    function mod:RemoveData()   return Isaac.RemoveModData(self) end
    return mod
end

-- Carga de mods: include() y require() resuelven dentro de la carpeta del mod --
local current_root = nil

function include(path)
    if not current_root then error("include() solo se puede usar mientras carga el mod", 2) end
    local rel = (path:gsub("%.lua$", "")):gsub("%.", "/")  -- sin '.', no hay '..'
    local f, err = loadfile_raw(current_root .. "/" .. rel .. ".lua")
    if not f then error(err, 2) end
    return f()
end

local function begin_mod(name, root)
    current_root = root
    package.path = root .. "/?.lua;" .. root .. "/?/init.lua"
end
local function end_mod()
    current_root = nil
    package.path = ""
end

return { dispatch = dispatch, msgh = msgh, begin_mod = begin_mod, end_mod = end_mod }
