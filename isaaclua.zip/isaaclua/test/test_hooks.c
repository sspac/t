/* Prueba de hooks.c con una "imagen" falsa: instala cuevas, sondea buzones, lee hooks.cfg. */
#include "../src/isaaclua.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>

int  il_hooks_install(void *base);
void il_hooks_tick(void);
void il_hooks_bump(unsigned i, uint64_t a0);
int  il_hooks_installed(unsigned i);
const char *il_hooks_name(unsigned i);
void il_hooks_reset(void);
uint32_t il_hooks_count(unsigned i);
#include "../src/hooks_table.h"

static int fails = 0, checks = 0;
static void check(int ok, const char *w) { checks++; if (!ok) fails++; printf("  %s %s\n", ok ? "ok:   " : "FALLA:", w); }
static void quiet(const char *l) { (void)l; }
static unsigned idx(const char *n) { for (unsigned i = 0; i < IL_NCANDS; i++) if (!strcmp(il_cands[i].name, n)) return i; return 9999; }
static const char *cmd(void) { static IlArg r; memset(&r, 0, sizeof r); return isaaclua_fire(22, IL_NO_PARAM, 0, NULL, &r) == 1 ? r.s : "?"; }

#define IMG_SIZE 0xb1c000UL
static uint8_t *make_image(void) {
    uint8_t *img = mmap(NULL, IMG_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    for (unsigned i = 0; i < IL_NCANDS; i++) *(uint32_t *)(img + (il_cands[i].vm - 0x100000000ULL)) = il_cands[i].word;
    mprotect(img, IMG_SIZE, PROT_READ | PROT_EXEC);   /* como lo deja el cargador del port */
    return img;
}

int main(int argc, char **argv) {
    const char *dump = argc > 1 ? argv[1] : "/tmp/hooks_dump.txt";
    if (system("rm -rf /tmp/il_hk && mkdir -p /tmp/il_hk") != 0) return 2;
    FILE *cfg = fopen("/tmp/il_hk/hooks.cfg", "w");
    fputs("# prueba\nentity_list = MC_POST_UPDATE   # comentario\nload_room_1 = MC_POST_NEW_ROOM\ntake_damage_1 = 11\nspawn_time_1 = MC_NO_EXISTE\n  \nlinea sin igual\n", cfg);
    fclose(cfg);
    IlHost host = { quiet, NULL, NULL };
    check(isaaclua_boot(NULL, "test/mods_cfg", "/tmp/il_hk", &host) == 1, "arranque con el mod de prueba");

    printf("== instalar en una imagen falsa\n");
    uint8_t *img = make_image();
    int n = il_hooks_install(img);
    check(n == (int)IL_NCANDS, "todos los candidatos se instalan");
    int allb = 1, intail = 1;
    FILE *d = fopen(dump, "w"); fprintf(d, "base %lx\n", (unsigned long)(uintptr_t)img);
    for (unsigned i = 0; i < IL_NCANDS; i++) {
        uint32_t *site = (uint32_t *)(img + (il_cands[i].vm - 0x100000000ULL));
        uint32_t w = *site;
        if ((w >> 26) != 0x05) allb = 0;
        int64_t imm = ((int64_t)(w & 0x3ffffff) << 38) >> 38;
        uint8_t *cave = (uint8_t *)site + imm * 4;
        uint64_t off = (uint64_t)(cave - img);
        if (off < 0xa81f68 || off + 40 > 0xa84000) intail = 0;
        fprintf(d, "hook %u site %lx cave %lx orig %08x slotidx %u\n", i, (unsigned long)((uint8_t *)site - img), (unsigned long)off, il_cands[i].word, i);
        for (int k = 0; k < 10; k++) fprintf(d, " %08x", ((uint32_t *)cave)[k]);
        fprintf(d, "\n");
    }
    fclose(d);
    check(allb, "cada sitio ahora contiene un salto b");
    check(intail, "todas las cuevas caen en el relleno de ceros al final de __TEXT");

    printf("== sondeo: el juego (simulado) sube contadores\n");
    il_hooks_bump(idx("entity_list"), 0x1111);
    il_hooks_bump(idx("entity_list"), 0x2222);
    il_hooks_bump(idx("entity_list"), 0x3333);
    il_hooks_bump(idx("load_room_1"), 0xABCD);
    for (int i = 0; i < 20; i++) il_hooks_bump(idx("take_damage_1"), 0x42);    /* mas del tope por frame */
    il_hooks_bump(idx("spawn_time_1"), 0x1);                                   /* callback desconocido: ignorado */
    il_hooks_bump(idx("hud_draw"), 0x1);                                       /* sin mapear: solo cuenta */
    il_hooks_tick();
    const char *s = cmd(); printf("       estado: %s\n", s);
    check(strcmp(s, "upd=3 room=1 dmg=8 ptr=1") == 0, "update x3, new_room x1 (con puntero), take_dmg limitado a 8 por frame");
    il_hooks_tick();
    check(strcmp(cmd(), "upd=3 room=1 dmg=8 ptr=1") == 0, "sin cambios -> no se vuelven a disparar");
    il_hooks_bump(idx("load_room_1"), 0xABCD); il_hooks_tick();
    check(strstr(cmd(), "room=2") != NULL, "otro cambio de sala se dispara");

    printf("== registro de calibracion\n");
    for (int i = 0; i < 130; i++) { il_hooks_bump(idx("hud_draw"), 1); il_hooks_tick(); }
    FILE *lg = fopen("/tmp/il_hk/hooks_log.txt", "r"); char buf[8192] = {0}; if (lg) { size_t got = fread(buf, 1, sizeof buf - 1, lg); (void)got; fclose(lg); }
    check(strstr(buf, "load_room_1") && strstr(buf, "MC_POST_NEW_ROOM"), "hooks_log.txt lista los contadores y el callback mapeado");
    check(strstr(buf, "hud_draw") && strstr(buf, "callback=-"), "los sin mapear aparecen con '-'");

    printf("== seguridad: sitio ya parcheado / sin espacio\n");
    il_hooks_reset();
    uint8_t *img2 = make_image();
    mprotect(img2, IMG_SIZE, PROT_READ | PROT_WRITE);
    *(uint32_t *)(img2 + (il_cands[idx("entity_list")].vm - 0x100000000ULL)) = 0x14000010;   /* alguien ya puso un b */
    mprotect(img2, IMG_SIZE, PROT_READ | PROT_EXEC);
    n = il_hooks_install(img2);
    check(n == (int)IL_NCANDS - 1 && !il_hooks_installed(idx("entity_list")), "un sitio distinto del original se omite sin tocarlo");
    check(*(uint32_t *)(img2 + (il_cands[idx("entity_list")].vm - 0x100000000ULL)) == 0x14000010, "y su contenido queda intacto");

    il_hooks_reset();
    uint8_t *img3 = make_image();
    mprotect(img3, IMG_SIZE, PROT_READ | PROT_WRITE);
    memset(img3 + 0xa81f68, 0xAB, 0xa84000 - 0xa81f68);                                      /* el relleno ya esta usado */
    mprotect(img3, IMG_SIZE, PROT_READ | PROT_EXEC);
    n = il_hooks_install(img3);
    check(n == 0, "sin espacio de ceros no se instala nada (y no se rompe)");

    il_hooks_reset();
    uint8_t *img4 = make_image();
    mprotect(img4, IMG_SIZE, PROT_READ | PROT_WRITE);
    for (uint32_t *w = (uint32_t *)(img4 + 0xa81f68); w < (uint32_t *)(img4 + 0xa84000); w += 20) *w = 0xDEADBEEF;   /* solo huecos cortos */
    mprotect(img4, IMG_SIZE, PROT_READ | PROT_EXEC);
    n = il_hooks_install(img4);
    check(n == 0, "huecos de ceros cortos (posibles tablas de otro parche) no se usan");

    il_hooks_reset(); isaaclua_shutdown();
    printf("\n%d/%d pruebas ok\n", checks - fails, checks);
    return fails ? 1 : 0;
}
