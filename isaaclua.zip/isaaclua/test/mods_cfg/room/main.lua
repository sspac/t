local mod = RegisterMod("RoomMod", 1)
local c = { upd = 0, room = 0, dmg = 0 }
local ptrs = 0
mod:AddCallback(ModCallbacks.MC_POST_UPDATE,   function() c.upd  = c.upd  + 1 end)
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, function(self, p) c.room = c.room + 1; if type(p) == "userdata" then ptrs = ptrs + 1 end end)
mod:AddCallback(ModCallbacks.MC_ENTITY_TAKE_DMG, function() c.dmg = c.dmg + 1 end)
mod:AddCallback(ModCallbacks.MC_EXECUTE_CMD, function()
    return string.format("upd=%d room=%d dmg=%d ptr=%d", c.upd, c.room, c.dmg, ptrs)
end)
