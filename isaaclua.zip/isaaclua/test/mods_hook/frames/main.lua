local mod = RegisterMod("Frames", 1)
local u, r = 0, 0
mod:AddCallback(ModCallbacks.MC_POST_UPDATE, function() u = u + 1 end)
mod:AddCallback(ModCallbacks.MC_POST_RENDER, function() r = r + 1 end)
mod:AddCallback(ModCallbacks.MC_EXECUTE_CMD, function()
    return string.format("u=%d r=%d frame=%d", u, r, Isaac.GetFrameCount())
end)
