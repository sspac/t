/* Simula la parte "juego" de libisaacport: una funcion por frame y quien la llama. */
static int g_calls = 0;
__attribute__((noinline, visibility("default"))) void mock_item_frame(void) { g_calls++; }
__attribute__((visibility("default"))) int mock_get_calls(void) { return g_calls; }
