/* Prueba en PC (x86) de la capa Lua: simula al port y dispara callbacks. */
#include "../src/isaaclua.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char logbuf[1 << 16];
static int  fails = 0, checks = 0;
static int  g_frame = 777;

static void host_log(const char *line) {
    size_t n = strlen(logbuf);
    snprintf(logbuf + n, sizeof logbuf - n, "%s\n", line);
}
static int host_frame(void) { return g_frame; }

static const char *find(const char *s) { return strstr(logbuf, s); }
static void check(int ok, const char *what) {
    checks++;
    if (!ok) { fails++; printf("  FALLA: %s\n", what); } else printf("  ok:    %s\n", what);
}
static void check_has(const char *s)  { char m[256]; snprintf(m, sizeof m, "log contiene \"%s\"", s); check(find(s) != NULL, m); }
static void check_not(const char *s)  { char m[256]; snprintf(m, sizeof m, "log NO contiene \"%s\"", s); check(find(s) == NULL, m); }
static void check_order(const char *a, const char *b) {
    const char *pa = find(a), *pb = find(b); char m[300];
    snprintf(m, sizeof m, "orden: \"%s\" antes de \"%s\"", a, b);
    check(pa && pb && pa < pb, m);
}
static void clear_log(void) { logbuf[0] = 0; }

int main(int argc, char **argv) {
    const char *scripts = argc > 1 ? argv[1] : "scripts";
    const char *mods    = argc > 2 ? argv[2] : "test/mods";
    const char *saves   = argc > 3 ? argv[3] : "/tmp/isaaclua_saves";
    IlHost host = { host_log, host_frame, NULL };

    printf("== arranque\n");
    int n = isaaclua_boot(scripts, mods, saves, &host);
    check(n == 2, "2 mods cargados (Alpha, BetaRuntime)");
    check(isaaclua_mods_failed() == 1, "1 mod con error (sintaxis)");
    check_has("alpha cargado: helper-ok / helper2-via-require");
    check_has("sandbox io=nil execute=nil loadlib=nil __il=nil");
    check_has("mod desactivado (disable.it): gamma_disabled");
    check_not("ESTO NO DEBE EJECUTARSE");
    check_has("mod con error: delta_syntax");

    printf("== prioridades y errores aislados (POST_UPDATE)\n");
    clear_log();
    int r = isaaclua_fire(1, IL_NO_PARAM, 0, NULL, NULL);
    check(r == 0, "fire devuelve 0 sin ret");
    check_has("fallo a proposito");
    check_order("update early frame=777", "update default");
    check_order("update default", "update late");
    check_has("update late"); /* el error de BetaRuntime no impidio a Alpha */

    printf("== filtro por parametro (USE_ITEM)\n");
    clear_log();
    IlArg a[1] = {{ IL_INT, 33, 0, NULL, NULL }};
    isaaclua_fire(3, 33, 1, a, NULL);
    check_has("use_item 33 recibio 33");
    clear_log();
    a[0].i = 99;
    isaaclua_fire(3, 99, 1, a, NULL);
    check_not("use_item 33");

    printf("== valores de retorno (PRE_USE_ITEM)\n");
    IlArg ret; memset(&ret, 0, sizeof ret);
    a[0].i = 5; r = isaaclua_fire(23, IL_NO_PARAM, 1, a, &ret);
    check(r == 1 && ret.type == IL_BOOL && ret.i == 0, "false llega como bool 0");
    a[0].i = 7; r = isaaclua_fire(23, IL_NO_PARAM, 1, a, &ret);
    check(r == 1 && ret.type == IL_STR && strcmp(ret.s, "texto") == 0, "string llega a C");
    a[0].i = 8; r = isaaclua_fire(23, IL_NO_PARAM, 1, a, &ret);
    check(r == 1 && ret.type == IL_INT && ret.i == 42, "entero llega a C");
    a[0].i = 6; r = isaaclua_fire(23, IL_NO_PARAM, 1, a, &ret);
    check(r == 0, "nil -> sin retorno");

    printf("== SaveModData / LoadModData\n");
    clear_log();
    isaaclua_fire(15, IL_NO_PARAM, 0, NULL, NULL);
    check_has("hasdata antes=false");
    check_has("hasdata despues=true dato=visitas=1");
    check_has("hasdata tras borrar=false");

    printf("== RemoveCallback\n");
    clear_log();
    isaaclua_fire(18, IL_NO_PARAM, 0, NULL, NULL);
    check_has("once-callback");
    clear_log();
    isaaclua_fire(18, IL_NO_PARAM, 0, NULL, NULL);
    check_not("once-callback");

    printf("== bucle infinito (RENDER): debe cortarse\n");
    clear_log();
    r = isaaclua_fire(2, IL_NO_PARAM, 0, NULL, NULL);
    check(r == 0, "fire regresa (no se cuelga)");
    check_has("limite de instrucciones");

    printf("== memoria desbocada (EVALUATE_CACHE): debe cortarse\n");
    clear_log();
    r = isaaclua_fire(8, IL_NO_PARAM, 0, NULL, NULL);
    check(r == 0, "fire regresa");
    check_has("not enough memory");
    clear_log();
    isaaclua_fire(1, IL_NO_PARAM, 0, NULL, NULL);
    check_has("update late");   /* sigue funcionando tras el fallo de memoria */

    printf("== callback inexistente / args variados\n");
    r = isaaclua_fire(999, IL_NO_PARAM, 0, NULL, NULL);
    check(r == 0, "callback sin registros -> 0");

    isaaclua_shutdown();
    check(isaaclua_fire(1, IL_NO_PARAM, 0, NULL, NULL) == -1, "tras shutdown -> -1");

    printf("\n%d/%d pruebas ok\n", checks - fails, checks);
    return fails ? 1 : 0;
}
