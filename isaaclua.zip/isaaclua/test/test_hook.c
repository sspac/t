/* Prueba del enganche por GOT/PLT con una biblioteca simulada (libmock.so). */
#include "../src/isaaclua.h"
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static int fails = 0, checks = 0;
static void check(int ok, const char *what) { checks++; if (!ok) fails++; printf("  %s %s\n", ok ? "ok:   " : "FALLA:", what); }
static void quiet(const char *l) { (void)l; }

static const char *cmd(void) {
    static IlArg r; memset(&r, 0, sizeof r);
    return isaaclua_fire(22, IL_NO_PARAM, 0, NULL, &r) == 1 ? r.s : "(sin respuesta)";
}

int main(int argc, char **argv) {
    const char *mock = argc > 1 ? argv[1] : "/tmp/libmock.so";
    const char *mods = argc > 2 ? argv[2] : "test/mods_hook";
    void *h = dlopen(mock, RTLD_NOW);
    if (!h) { printf("dlopen: %s\n", dlerror()); return 2; }
    void (*present)(void) = (void (*)(void))dlsym(h, "mock_present");
    int  (*calls)(void)   = (int (*)(void))dlsym(h, "mock_get_calls");

    IlHost host = { quiet, NULL, NULL };
    printf("== arranque\n");
    check(isaaclua_boot(NULL, mods, "/tmp/isaaclua_saves3", &host) == 1, "mod Frames cargado con scripts embebidos");

    printf("== sin enganche: el juego sigue igual\n");
    for (int i = 0; i < 4; i++) present();
    check(calls() == 4, "la funcion original corre 4 veces");
    check(strcmp(cmd(), "u=0 r=0 frame=0") == 0, "ningun callback disparado todavia");

    printf("== instalar enganche\n");
    check(isaaclua_install_frame_hook("libmock.so", "no_existe") < 0, "simbolo inexistente -> error limpio");
    check(isaaclua_install_frame_hook("libnada.so", "mock_item_frame") < 0, "biblioteca inexistente -> error limpio");
    check(isaaclua_install_frame_hook("libmock.so", "mock_item_frame") == 0, "enganche instalado");
    for (int i = 0; i < 10; i++) present();
    check(calls() == 14, "la original SIGUE corriendo (10 llamadas mas)");
    const char *s = cmd();
    printf("       estado: %s\n", s);
    check(strcmp(s, "u=5 r=10 frame=5") == 0, "10 renders, 5 updates (divisor 2), GetFrameCount = updates");

    printf("== divisor\n");
    isaaclua_set_update_divisor(1);
    for (int i = 0; i < 4; i++) present();
    check(strcmp(cmd(), "u=9 r=14 frame=9") == 0, "divisor 1: un update por frame");
    isaaclua_set_update_divisor(0);
    for (int i = 0; i < 4; i++) present();
    check(strcmp(cmd(), "u=9 r=18 frame=9") == 0, "divisor 0: solo render");

    printf("== quitar enganche\n");
    isaaclua_remove_frame_hook();
    int before = calls();
    for (int i = 0; i < 3; i++) present();
    check(calls() == before + 3, "la original corre");
    check(strcmp(cmd(), "u=9 r=18 frame=9") == 0, "ya no se disparan callbacks");
    check(isaaclua_install_frame_hook("libmock.so", "mock_item_frame") == 0, "se puede volver a instalar");
    present();
    check(strcmp(cmd(), "u=9 r=19 frame=9") == 0, "y vuelve a funcionar");
    isaaclua_remove_frame_hook();

    printf("== instalacion diferida: la biblioteca aparece DESPUES\n");
    check(isaaclua_install_frame_hook_async("libmock2.so", "mock_item_frame", 3000) == 1, "pendiente (libmock2 aun no existe)");
    void *h2 = dlopen("/tmp/libmock2.so", RTLD_NOW);
    check(h2 != NULL, "libmock2.so se carga despues");
    if (h2) {
        void (*present2)(void) = (void (*)(void))dlsym(h2, "mock_present");
        int r0 = 0, r1 = 0; sscanf(cmd(), "u=%*d r=%d", &r0);
        for (int i = 0; i < 60 && r1 <= r0; i++) { usleep(50 * 1000); present2(); sscanf(cmd(), "u=%*d r=%d", &r1); }
        check(r1 > r0, "el hilo la encontro y el enganche funciona");
    }
    isaaclua_remove_frame_hook();
    isaaclua_shutdown();
    printf("\n%d/%d pruebas ok\n", checks - fails, checks);
    return fails ? 1 : 0;
}
