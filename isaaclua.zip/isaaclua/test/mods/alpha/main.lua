local mod = RegisterMod("Alpha", 1)
local helper  = include("scripts.helper")
local helper2 = require("scripts.helper2")
Isaac.DebugString("alpha cargado: " .. helper.name .. " / " .. helper2.name)

-- sandbox
Isaac.DebugString("sandbox io=" .. tostring(io) .. " execute=" .. tostring(os.execute) ..
                  " loadlib=" .. tostring(package.loadlib) .. " __il=" .. tostring(__il))

mod:AddCallback(ModCallbacks.MC_POST_UPDATE, function(self)
    Isaac.DebugString("update default")
end)
mod:AddPriorityCallback(ModCallbacks.MC_POST_UPDATE, CallbackPriority.LATE, function(self)
    Isaac.DebugString("update late")
end)
mod:AddPriorityCallback(ModCallbacks.MC_POST_UPDATE, CallbackPriority.EARLY, function(self)
    Isaac.DebugString("update early frame=" .. Game():GetFrameCount())
end)

-- filtro por parametro
mod:AddCallback(ModCallbacks.MC_USE_ITEM, function(self, item)
    Isaac.DebugString("use_item 33 recibio " .. tostring(item))
    return true
end, 33)

-- callbacks con retorno (PRE_)
mod:AddCallback(ModCallbacks.MC_PRE_USE_ITEM, function(self, item)
    if item == 5 then return false end
    if item == 7 then return "texto" end
    if item == 8 then return 42 end
end)

-- datos guardados
mod:AddCallback(ModCallbacks.MC_POST_GAME_STARTED, function(self)
    Isaac.DebugString("hasdata antes=" .. tostring(self:HasData()))
    self:SaveData("visitas=1")
    Isaac.DebugString("hasdata despues=" .. tostring(self:HasData()) .. " dato=" .. tostring(self:LoadData()))
    self:RemoveData()
    Isaac.DebugString("hasdata tras borrar=" .. tostring(self:HasData()))
end)

-- RemoveCallback
local function once() Isaac.DebugString("once-callback") end
mod:AddCallback(ModCallbacks.MC_POST_NEW_LEVEL, once)
mod:AddCallback(ModCallbacks.MC_POST_NEW_LEVEL, function(self)
    mod:RemoveCallback(ModCallbacks.MC_POST_NEW_LEVEL, once)
end)
