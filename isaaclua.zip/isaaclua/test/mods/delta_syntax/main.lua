local mod = RegisterMod("Delta", 1
this is not lua
