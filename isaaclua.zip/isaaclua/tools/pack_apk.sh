#!/bin/sh
# Empaqueta una carpeta de APK descomprimido, la alinea y la firma.
# Uso: sh tools/pack_apk.sh CARPETA_APK SALIDA.apk [keystore]
# Necesita: zip, y zipalign + apksigner (Android build-tools; en Termux: pkg install apksigner zipalign).
# Crea un keystore de depuracion si no existe (keytool).
set -e
DIR="${1:?uso: pack_apk.sh CARPETA_APK SALIDA.apk [keystore]}"
OUT="$(cd "$(dirname "${2:?falta SALIDA.apk}")" && pwd)/$(basename "$2")"
KS="${3:-$HOME/isaaclua-debug.keystore}"
[ -f "$DIR/AndroidManifest.xml" ] || { echo "error: $DIR no parece un APK descomprimido (falta AndroidManifest.xml)"; exit 1; }
command -v zip >/dev/null || { echo "error: falta 'zip'"; exit 1; }

TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
rm -f "$OUT"
cd "$DIR"
# 1) todo lo comprimible, sin firmas viejas ni copias .orig
zip -q -r -X "$TMP/u.apk" . -x 'lib/*' 'resources.arsc' 'META-INF/*.SF' 'META-INF/*.RSA' \
    'META-INF/*.DSA' 'META-INF/*.EC' 'META-INF/MANIFEST.MF' '*.orig'
# 2) sin comprimir: las .so y resources.arsc (Android moderno lo exige para alinearlas)
zip -q -r -X -0 "$TMP/u.apk" lib -x '*.orig'
[ -f resources.arsc ] && zip -q -X -0 "$TMP/u.apk" resources.arsc
cd - >/dev/null

if command -v zipalign >/dev/null; then
  zipalign -p -f 4 "$TMP/u.apk" "$TMP/a.apk"
else
  echo "aviso: no hay zipalign; se firma sin alinear (puede fallar si el manifest usa extractNativeLibs=false)"
  cp "$TMP/u.apk" "$TMP/a.apk"
fi

if [ ! -f "$KS" ]; then
  command -v keytool >/dev/null || { echo "error: falta keytool para crear el keystore"; exit 1; }
  keytool -genkeypair -keystore "$KS" -storepass android -keypass android -alias isaaclua \
    -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=isaaclua" >/dev/null 2>&1
  echo "keystore creado: $KS"
fi
if command -v apksigner >/dev/null; then
  apksigner sign --ks "$KS" --ks-pass pass:android --key-pass pass:android --out "$OUT" "$TMP/a.apk"
  echo "listo (firmado): $OUT"
else
  cp "$TMP/a.apk" "$OUT"
  echo "AVISO: no hay apksigner; $OUT SIN FIRMAR. Firmalo con apksigner o uber-apk-signer antes de instalar."
fi
