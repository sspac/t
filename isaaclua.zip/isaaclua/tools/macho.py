import struct, sys
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from a64 import dis
BASE = 0x100000000
class Macho:
    def __init__(self, path):
        self.d = d = open(path, 'rb').read()
        magic, cpu, sub, ft, n, sz, fl, _ = struct.unpack('<8I', d[:32]); o = 32
        self.segs = []; self.sects = {}; self.fstarts = None
        for _ in range(n):
            c, s = struct.unpack('<2I', d[o:o+8])
            if c == 0x19:
                name = d[o+8:o+24].rstrip(b'\0').decode()
                vm, vs, fo, fs, mx, ip, ns, fl2 = struct.unpack('<4Q2I2I', d[o+24:o+72])
                self.segs.append((name, vm, vs, fo, fs)); so = o + 72
                for k in range(ns):
                    sn = d[so:so+16].rstrip(b'\0').decode()
                    addr, size, off = struct.unpack('<QQI', d[so+32:so+52])
                    self.sects[sn] = (addr, size, off); so += 80
            if c == 0x26:  # LC_FUNCTION_STARTS
                self.fstarts = struct.unpack('<II', d[o+8:o+16])
            o += s
        # funciones
        self.funcs = []
        if self.fstarts:
            off, size = self.fstarts; p = off; end = off + size; addr = BASE
            while p < end:
                v = 0; sh = 0
                while True:
                    b = d[p]; p += 1; v |= (b & 0x7f) << sh; sh += 7
                    if not b & 0x80: break
                if v == 0: break
                addr += v; self.funcs.append(addr)
    def v2o(self, v):
        for name, vm, vs, fo, fs in self.segs:
            if vm <= v < vm + fs: return fo + v - vm
    def word(self, v): return struct.unpack_from('<I', self.d, self.v2o(v))[0]
    def q(self, v): return struct.unpack_from('<Q', self.d, self.v2o(v))[0]
    def func_of(self, a):
        import bisect
        i = bisect.bisect_right(self.funcs, a) - 1
        return self.funcs[i] if i >= 0 else None
    def func_end(self, f):
        import bisect
        i = bisect.bisect_right(self.funcs, f)
        return self.funcs[i] if i < len(self.funcs) else f + 0x100
    def cstr_addr(self, s):
        a, sz, off = self.sects['__cstring']
        i = self.d.find(s.encode() + b'\0', off, off + sz)
        return a + (i - off) if i >= 0 else None
    def xrefs(self, target):
        a, sz, off = self.sects['__text']
        out = []; d = self.d
        for i in range(0, sz - 4, 4):
            w = struct.unpack_from('<I', d, off + i)[0]
            if (w & 0x9F000000) == 0x90000000:
                imm = ((w >> 5) & 0x7ffff) << 2 | ((w >> 29) & 3)
                imm = imm - (1 << 21) if imm & (1 << 20) else imm
                pc = a + i; page = (pc & ~0xfff) + (imm << 12)
                n = struct.unpack_from('<I', d, off + i + 4)[0]
                if (n & 0xFF800000) == 0x91000000 and ((n >> 5) & 31) == (w & 31) and page + ((n >> 10) & 0xfff) == target:
                    out.append(pc)
        return out
    def show(self, a, n=8):
        for k in range(n):
            w = self.word(a + 4*k); print('   %x: %08x  %s' % (a + 4*k, w, dis(w, a + 4*k)))
def pc_independent(w):
    return not ((w & 0x1F000000) == 0x10000000 or (w >> 26) in (0b000101, 0b100101) or (w & 0xFF000010) == 0x54000000
                or ((w >> 25) & 0x3f) in (0b011010, 0b011011) or (w & 0x3B000000) == 0x18000000)
