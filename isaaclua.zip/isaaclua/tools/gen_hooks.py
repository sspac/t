#!/usr/bin/env python3
"""Genera src/hooks_table.h (candidatos de enganche) a partir de isaac.arm64.
Uso: python3 tools/gen_hooks.py RUTA/isaac.arm64 [salida.h]"""
import sys, re, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from macho import Macho, pc_independent, BASE

m = Macho(sys.argv[1])
out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src', 'hooks_table.h')
cands = []   # (nombre, vmaddr)
fs = set(m.funcs)

# 1) sondas del port que son inicio de funcion (etiquetas del autor del port)
probes = [('room_drawn', 0x1005c2630), ('entity_list', 0x10076436c), ('effects_wiped', 0x1006fdd80),
          ('stats_column', 0x1006efac4), ('sound_played', 0x100671c8c), ('item_button_action', 0x100864434),
          ('hud_draw', 0x100578464)]
for n, a in probes: cands.append((n, a))

# 2) funciones que contienen cadenas del juego (cada cadena aparece en varias funciones)
anchors = [('load_room', 'Level::load_room: could not choose a door from where to enter off grid room'),
           ('take_damage', 'Entity TakeDamage should not be called for Entity Player!'),
           ('start_seed', 'Start seed is not initialized'),
           ('spawn_time', 'Total entity spawn time: '),
           ('door_spawn', 'invalid GridIndex while spawning door (slot %d)'),
           ('wrong_stage', 'Wrong Stage')]
for name, s in anchors:
    a = m.cstr_addr(s)
    seen = []
    for x in m.xrefs(a):
        f = m.func_of(x)
        if f not in seen: seen.append(f)
    for i, f in enumerate(seen): cands.append(('%s_%d' % (name, i + 1), f))

rows = []
for n, a in cands:
    w = m.word(a)
    if not pc_independent(w):
        print('descartado (1a instruccion depende de PC):', n, hex(a)); continue
    rows.append((n, a, w))
with open(out, 'w') as f:
    f.write('/* GENERADO por tools/gen_hooks.py desde isaac.arm64 (1.77/1.777) - no editar a mano */\n')
    f.write('typedef struct { const char *name; unsigned long long vm; unsigned int word; } IlCand;\n')
    f.write('static const IlCand il_cands[] = {\n')
    for n, a, w in rows: f.write('    { "%s", 0x%xULL, 0x%08x },\n' % (n, a, w))
    f.write('};\n#define IL_NCANDS (sizeof il_cands / sizeof il_cands[0])\n')
print('candidatos:', len(rows), '->', out)
