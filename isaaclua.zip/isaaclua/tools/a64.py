import struct, sys, subprocess, re

def sx(v, bits): return v - (1 << bits) if v & (1 << (bits - 1)) else v
def R(n, sf=1, sp=False):
    if n == 31: return ('sp' if sp else ('xzr' if sf else 'wzr'))
    return ('x%d' if sf else 'w%d') % n

def decode_bitmask(N, imms, immr, M):
    length = (N << 6) | ((~imms) & 0x3f)
    if length == 0: return None
    len_ = length.bit_length() - 1
    esize = 1 << len_
    levels = esize - 1
    S = imms & levels; Rr = immr & levels
    welem = (1 << (S + 1)) - 1
    mask = (1 << esize) - 1
    rot = ((welem >> Rr) | (welem << (esize - Rr))) & mask
    out = 0
    for i in range(M // esize): out |= rot << (i * esize)
    return out

CC = ['eq','ne','cs','cc','mi','pl','vs','vc','hi','ls','ge','lt','gt','le','al','nv']

def dis(w, pc, plt=None, syms=None):
    sf = w >> 31
    def tgt(t):
        if plt and t in plt: return '%x <%s@plt>' % (t, plt[t])
        if syms:
            s = syms.get(t)
            if s: return '%x <%s>' % (t, s)
        return '%x' % t
    if w == 0xD503201F: return 'nop'
    if w == 0xD65F03C0: return 'ret'
    if (w & 0xFFFFFC1F) == 0xD61F0000: return 'br %s' % R((w >> 5) & 31)
    if (w & 0xFFFFFC1F) == 0xD63F0000: return 'blr %s' % R((w >> 5) & 31)
    if (w & 0xFFFFFC1F) == 0xD65F0000: return 'ret %s' % R((w >> 5) & 31)
    if (w >> 26) == 0b000101: return 'b %s' % tgt(pc + sx(w & 0x3ffffff, 26) * 4)
    if (w >> 26) == 0b100101: return 'bl %s' % tgt(pc + sx(w & 0x3ffffff, 26) * 4)
    if (w & 0xFF000010) == 0x54000000: return 'b.%s %s' % (CC[w & 15], tgt(pc + sx((w >> 5) & 0x7ffff, 19) * 4))
    if ((w >> 25) & 0x3f) == 0b011010: return '%s %s, %s' % ('cbnz' if (w >> 24) & 1 else 'cbz', R(w & 31, sf), tgt(pc + sx((w >> 5) & 0x7ffff, 19) * 4))
    if ((w >> 25) & 0x3f) == 0b011011:
        b = ((w >> 31) << 5) | ((w >> 19) & 31)
        return '%s %s, #%d, %s' % ('tbnz' if (w >> 24) & 1 else 'tbz', R(w & 31, 1 if b >= 32 else 0), b, tgt(pc + sx((w >> 5) & 0x3fff, 14) * 4))
    if (w & 0x1F000000) == 0x10000000:
        imm = sx(((w >> 5) & 0x7ffff) << 2 | ((w >> 29) & 3), 21)
        if w >> 31: return 'adrp %s, %x' % (R(w & 31), ((pc & ~0xfff) + (imm << 12)))
        return 'adr %s, %x' % (R(w & 31), pc + imm)
    top = (w >> 23) & 0x3f
    if top == 0b100010:  # add/sub imm
        op = (w >> 30) & 1; S = (w >> 29) & 1; sh = (w >> 22) & 1; imm = (w >> 10) & 0xfff
        if sh: imm <<= 12
        rn, rd = (w >> 5) & 31, w & 31
        name = ('sub' if op else 'add') + ('s' if S else '')
        if S and rd == 31: return '%s %s, #%#x' % ('cmp' if op else 'cmn', R(rn, sf, True), imm)
        if not op and not S and imm == 0 and (rn == 31 or rd == 31): return 'mov %s, %s' % (R(rd, sf, True), R(rn, sf, True))
        return '%s %s, %s, #%#x' % (name, R(rd, sf, not S), R(rn, sf, True), imm)
    if top == 0b100101:  # move wide
        opc = (w >> 29) & 3; hw = (w >> 21) & 3; imm = (w >> 5) & 0xffff; rd = w & 31
        if opc == 0: return 'movn %s, #%#x, lsl #%d' % (R(rd, sf), imm, hw * 16)
        if opc == 2: return 'mov %s, #%#x' % (R(rd, sf), imm << (hw * 16)) if hw == 0 else 'movz %s, #%#x, lsl #%d' % (R(rd, sf), imm, hw * 16)
        if opc == 3: return 'movk %s, #%#x, lsl #%d' % (R(rd, sf), imm, hw * 16)
    if top == 0b100100:  # logical imm
        opc = (w >> 29) & 3; N = (w >> 22) & 1; immr = (w >> 16) & 63; imms = (w >> 10) & 63
        v = decode_bitmask(N, imms, immr, 64 if sf else 32)
        rn, rd = (w >> 5) & 31, w & 31
        nm = ['and', 'orr', 'eor', 'ands'][opc]
        if opc == 3 and rd == 31: return 'tst %s, #%#x' % (R(rn, sf), v or 0)
        if opc == 1 and rn == 31: return 'mov %s, #%#x' % (R(rd, sf, True), v or 0)
        return '%s %s, %s, #%#x' % (nm, R(rd, sf, opc != 3), R(rn, sf), v or 0)
    if top == 0b100110:  # bitfield
        opc = (w >> 29) & 3; immr = (w >> 16) & 63; imms = (w >> 10) & 63; rn, rd = (w >> 5) & 31, w & 31
        if opc == 2:
            if imms == (63 if sf else 31): return 'lsr %s, %s, #%d' % (R(rd, sf), R(rn, sf), immr)
            if imms + 1 == immr: return 'lsl %s, %s, #%d' % (R(rd, sf), R(rn, sf), (64 if sf else 32) - immr)
            return 'ubfx/ubfm %s, %s, #%d, #%d' % (R(rd, sf), R(rn, sf), immr, imms)
        if opc == 0:
            if imms == 31 and sf and immr == 0: return 'sxtw %s, %s' % (R(rd), R(rn, 0))
            if imms == (63 if sf else 31): return 'asr %s, %s, #%d' % (R(rd, sf), R(rn, sf), immr)
            return 'sbfm %s, %s, #%d, #%d' % (R(rd, sf), R(rn, sf), immr, imms)
        return 'bfm %s, %s, #%d, #%d' % (R(rd, sf), R(rn, sf), immr, imms)
    # load/store
    if ((w >> 27) & 7) == 0b111 and ((w >> 26) & 1) == 0 and ((w >> 24) & 3) in (0, 1):
        size = w >> 30; opc = (w >> 22) & 3; rn, rt = (w >> 5) & 31, w & 31
        sz = ['b', 'h', '', ''][size] if size < 2 else ''
        isload = opc != 0
        if opc == 2 and size == 3: return 'prfm'
        sg = (opc >= 2)
        base = R(rn, 1, True)
        if ((w >> 24) & 3) == 1:
            imm = ((w >> 10) & 0xfff) << size
            nm = ('ldr' if isload else 'str') + ('s' if sg else '') + sz
            rtn = R(rt, 1 if (size == 3 or (sg and opc == 2 and size < 3 and False)) else (1 if (sg and opc == 2) else 0))
            if size == 3: rtn = R(rt, 1)
            return '%s %s, [%s, #%#x]' % (nm, rtn, base, imm)
        imm9 = sx((w >> 12) & 0x1ff, 9); mode = (w >> 10) & 3
        nm = ('ldr' if isload else 'str') + ('s' if sg else '') + sz
        if mode == 0: nm = nm.replace('ldr', 'ldur').replace('str', 'stur')
        rtn = R(rt, 1 if size == 3 else 0)
        if mode == 3: return '%s %s, [%s, #%d]!' % (nm, rtn, base, imm9)
        if mode == 1: return '%s %s, [%s], #%d' % (nm, rtn, base, imm9)
        return '%s %s, [%s, #%d]' % (nm, rtn, base, imm9)
    if ((w >> 27) & 7) == 0b111 and ((w >> 26) & 1) == 0 and ((w >> 24) & 3) == 0 and (w >> 21) & 1 and ((w >> 10) & 3) == 2:
        size = w >> 30; opc = (w >> 22) & 3
        nm = ('ldr' if opc else 'str') + ['b', 'h', '', ''][size]
        return '%s %s, [%s, %s]' % (nm, R(w & 31, 1 if size == 3 else 0), R((w >> 5) & 31, 1, True), R((w >> 16) & 31))
    if ((w >> 27) & 7) == 0b101 and ((w >> 26) & 1) == 0 and ((w >> 25) & 1) == 0:  # ldp/stp
        opc = w >> 30; mode = (w >> 23) & 3; L = (w >> 22) & 1
        imm7 = sx((w >> 15) & 0x7f, 7) << (3 if opc == 2 else 2)
        rt2, rn, rt = (w >> 10) & 31, (w >> 5) & 31, w & 31
        sfp = 1 if opc == 2 else 0
        nm = 'ldp' if L else 'stp'
        b = R(rn, 1, True)
        if mode == 1: return '%s %s, %s, [%s], #%d' % (nm, R(rt, sfp), R(rt2, sfp), b, imm7)
        if mode == 3: return '%s %s, %s, [%s, #%d]!' % (nm, R(rt, sfp), R(rt2, sfp), b, imm7)
        return '%s %s, %s, [%s, #%d]' % (nm, R(rt, sfp), R(rt2, sfp), b, imm7)
    if ((w >> 27) & 7) == 0b011 and ((w >> 26) & 1) == 0 and ((w >> 24) & 3) == 0:  # ldr literal
        opc = w >> 30
        return 'ldr %s, %s' % (R(w & 31, 1 if opc == 1 else 0), tgt(pc + sx((w >> 5) & 0x7ffff, 19) * 4))
    # data processing (register)
    if ((w >> 24) & 0x1f) == 0b01010:  # logical shifted
        opc = (w >> 29) & 3; N = (w >> 21) & 1; sh = (w >> 22) & 3; imm6 = (w >> 10) & 63
        rm, rn, rd = (w >> 16) & 31, (w >> 5) & 31, w & 31
        if opc == 1 and N == 0 and rn == 31 and imm6 == 0 and sh == 0: return 'mov %s, %s' % (R(rd, sf), R(rm, sf))
        nm = [['and', 'bic'], ['orr', 'orn'], ['eor', 'eon'], ['ands', 'bics']][opc][N]
        if opc == 3 and rd == 31 and N == 0: nm = 'tst'; return 'tst %s, %s' % (R(rn, sf), R(rm, sf))
        return '%s %s, %s, %s%s' % (nm, R(rd, sf), R(rn, sf), R(rm, sf), (', %s #%d' % (['lsl', 'lsr', 'asr', 'ror'][sh], imm6)) if imm6 else '')
    if ((w >> 24) & 0x1f) == 0b01011 and not (w >> 21) & 1:  # add/sub shifted
        op = (w >> 30) & 1; S = (w >> 29) & 1; sh = (w >> 22) & 3; imm6 = (w >> 10) & 63
        rm, rn, rd = (w >> 16) & 31, (w >> 5) & 31, w & 31
        if S and rd == 31: return '%s %s, %s' % ('cmp' if op else 'cmn', R(rn, sf), R(rm, sf))
        return '%s%s %s, %s, %s%s' % ('sub' if op else 'add', 's' if S else '', R(rd, sf), R(rn, sf), R(rm, sf), (', %s #%d' % (['lsl', 'lsr', 'asr', 'ror'][sh], imm6)) if imm6 else '')
    if ((w >> 21) & 0x3ff) == 0b0011010100 or ((w >> 21) & 0xff) == 0b11010100:  # csel family
        op = (w >> 30) & 1; op2 = (w >> 10) & 3
        nm = {(0, 0): 'csel', (0, 1): 'csinc', (1, 0): 'csinv', (1, 1): 'csneg'}[(op, op2)]
        rm, rn, rd, cond = (w >> 16) & 31, (w >> 5) & 31, w & 31, (w >> 12) & 15
        if nm == 'csinc' and rn == 31 and rm == 31: return 'cset %s, %s' % (R(rd, sf), CC[cond ^ 1])
        return '%s %s, %s, %s, %s' % (nm, R(rd, sf), R(rn, sf), R(rm, sf), CC[cond])
    if ((w >> 21) & 0xff) == 0b11010110 and ((w >> 11) & 31) == 0b00100:
        nm = ['lslv', 'lsrv', 'asrv', 'rorv'][(w >> 10) & 3]
        return '%s %s, %s, %s' % (nm, R(w & 31, sf), R((w >> 5) & 31, sf), R((w >> 16) & 31, sf))
    if ((w >> 24) & 0x1f) == 0b11011:
        o0 = (w >> 15) & 1; rm, ra, rn, rd = (w >> 16) & 31, (w >> 10) & 31, (w >> 5) & 31, w & 31
        if ra == 31: return '%s %s, %s, %s' % ('msub-neg' if o0 else 'mul', R(rd, sf), R(rn, sf), R(rm, sf))
        return '%s %s, %s, %s, %s' % ('msub' if o0 else 'madd', R(rd, sf), R(rn, sf), R(rm, sf), R(ra, sf))
    if (w & 0xFFE0FC00) == 0xD4000000 or (w & 0xFFE0001F) == 0xD4200000: return 'brk/svc'
    return '.inst %#010x' % w

class Elf:
    def __init__(self, path):
        self.d = open(path, 'rb').read()
        d = self.d
        shoff = struct.unpack_from('<Q', d, 0x28)[0]
        shentsize, shnum, shstrndx = struct.unpack_from('<HHH', d, 0x3A)
        self.sec = {}
        secs = []
        for i in range(shnum):
            name, typ, flags, addr, off, size, link, info, align, entsz = struct.unpack_from('<IIQQQQIIQQ', d, shoff + i * shentsize)
            secs.append((name, typ, flags, addr, off, size, link, info, entsz))
        stroff = secs[shstrndx][4]
        for s in secs:
            n = d[stroff + s[0]:d.index(b'\0', stroff + s[0])].decode()
            self.sec[n] = s
        # simbolos dinamicos
        ds = self.sec['.dynsym']; st = self.sec['.dynstr']
        self.dyn = []
        for i in range(ds[5] // 24):
            nm, info, other, shndx, val, sz = struct.unpack_from('<IBBHQQ', d, ds[4] + i * 24)
            name = d[st[4] + nm:d.index(b'\0', st[4] + nm)].decode()
            self.dyn.append((name, val, sz, shndx))
        self.byname = {n: (v, s) for n, v, s, x in self.dyn if x != 0}
        self.byaddr = {v: n for n, v, s, x in self.dyn if x != 0 and v}
        # PLT: got slot -> nombre
        rp = self.sec['.rela.plt']
        self.got = {}
        for i in range(rp[5] // 24):
            off, info, add = struct.unpack_from('<QQq', d, rp[4] + i * 24)
            self.got[off] = self.dyn[info >> 32][0]
        self.plt = {}
        if '.plt' in self.sec:
            p = self.sec['.plt']
            for a in range(p[3], p[3] + p[5], 4):
                w = self.word(a)
                if (w & 0x9F000000) == 0x90000000 and (w & 31) == 16:  # adrp x16
                    nxt = self.word(a + 4)
                    if (nxt & 0xFFC00000) == 0xF9400000 and ((nxt >> 5) & 31) == 16:
                        imm = sx(((w >> 5) & 0x7ffff) << 2 | ((w >> 29) & 3), 21)
                        page = (a & ~0xfff) + (imm << 12)
                        slot = page + (((nxt >> 10) & 0xfff) << 3)
                        if slot in self.got: self.plt[a] = self.got[slot]
    def off(self, vaddr):
        for n in ('.plt', '.text', '.rodata', '.init', '.fini', '.data.rel.ro', '.data'):
            s = self.sec.get(n)
            if s and s[3] <= vaddr < s[3] + s[5]: return s[4] + vaddr - s[3]
        return vaddr
    def word(self, vaddr): return struct.unpack_from('<I', self.d, self.off(vaddr))[0]
    def disasm(self, addr, size):
        out = []
        for a in range(addr, addr + size, 4):
            out.append('%7x: %08x  %s' % (a, self.word(a), dis(self.word(a), a, self.plt, self.byaddr)))
        return '\n'.join(out)

if __name__ == '__main__':
    e = Elf(sys.argv[1])
    for nm in sys.argv[2:]:
        a, s = e.byname[nm]
        print('== %s @%x size %#x' % (nm, a, s)); print(e.disasm(a, s or 0x40))
