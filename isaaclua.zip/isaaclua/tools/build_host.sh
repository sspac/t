#!/bin/sh
# Compila y corre las pruebas en PC (usa el Lua incluido). Uso: sh tools/build_host.sh
set -e
cd "$(dirname "$0")/.."
LUA="${LUA:-third_party/lua-5.3.3}"
SRCS=$(ls "$LUA"/*.c)
CF="-O1 -g -Wall -Wextra -DLUA_USE_POSIX -I$LUA -pthread"

echo "### pruebas del nucleo"
gcc $CF $SRCS src/isaaclua.c src/frame_hook.c src/hooks.c test/test_host.c -lm -ldl -o /tmp/isaaclua_test
rm -rf /tmp/isaaclua_saves
/tmp/isaaclua_test scripts test/mods /tmp/isaaclua_saves

echo; echo "### pruebas del enganche por frame (biblioteca simulada)"
gcc -shared -fPIC -O1 test/mock/mock_game.c test/mock/mock_present.c -o /tmp/libmock.so
gcc -shared -fPIC -O1 test/mock/mock_game.c test/mock/mock_present.c -o /tmp/libmock2.so
gcc $CF $SRCS src/isaaclua.c src/frame_hook.c src/hooks.c test/test_hook.c -lm -ldl -o /tmp/isaaclua_hooktest
/tmp/isaaclua_hooktest /tmp/libmock.so test/mods_hook

echo; echo "### pruebas de enganches en isaac.arm64 (imagen falsa) + emulacion de las cuevas"
gcc $CF $SRCS src/isaaclua.c src/frame_hook.c src/hooks.c test/test_hooks.c -lm -ldl -o /tmp/isaaclua_hk2
/tmp/isaaclua_hk2 /tmp/hooks_dump.txt
python3 tools/emu_cave_test.py /tmp/hooks_dump.txt
