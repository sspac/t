#!/bin/sh
# Mete isaaclua en un APK ya descomprimido (la carpeta con lib/, assets/, classes.dex...).
# Uso: sh tools/install_into_apk.sh CARPETA_APK [libil.so]
# - copia libil.so a lib/arm64-v8a/
# - parchea lib/arm64-v8a/libisaacport.so (guarda copia .orig) para que cargue libil.so
set -e
DIR="${1:?uso: install_into_apk.sh CARPETA_APK [libil.so]}"
SO="${2:-libil.so}"
HERE="$(cd "$(dirname "$0")" && pwd)"
LIBDIR="$DIR/lib/arm64-v8a"
[ -d "$LIBDIR" ] || { echo "error: no existe $LIBDIR"; exit 1; }
[ -f "$LIBDIR/libisaacport.so" ] || { echo "error: no hay libisaacport.so en $LIBDIR"; exit 1; }
[ -f "$SO" ] || { echo "error: no encuentro $SO (compilalo con: sh tools/build_android.sh)"; exit 1; }

[ -f "$LIBDIR/libisaacport.so.orig" ] || cp "$LIBDIR/libisaacport.so" "$LIBDIR/libisaacport.so.orig"
python3 "$HERE/patch_needed.py" "$LIBDIR/libisaacport.so.orig" "$LIBDIR/libisaacport.so"
cp "$SO" "$LIBDIR/libil.so"
echo "listo: $LIBDIR/libil.so + libisaacport.so parcheado (original en libisaacport.so.orig, no lo empaquetes)"
