#!/usr/bin/env python3
"""
patch_needed.py - hace que libisaacport.so cargue libil.so (isaaclua) como dependencia.

No mueve ni agranda nada: sustituye EN SITIO el nombre de una dependencia que ya existe
(por defecto "liblog.so", 9 letras) por "libil.so" (8 letras; sobra 1 byte, que queda en cero). libil.so a su vez depende de
liblog.so (se compila con -llog), asi que los simbolos de liblog siguen resolviendose.

Uso:  python3 patch_needed.py ENTRADA.so SALIDA.so [viejo=liblog.so] [nuevo=libil.so]
Si ENTRADA ya tiene la dependencia nueva, copia el archivo sin cambios.
"""
import struct, sys, shutil

def main():
    if len(sys.argv) < 3:
        print(__doc__); return 2
    src, dst = sys.argv[1], sys.argv[2]
    old = (sys.argv[3] if len(sys.argv) > 3 else "liblog.so").encode()
    new = (sys.argv[4] if len(sys.argv) > 4 else "libil.so").encode()
    if len(new) > len(old):
        print("error: el nombre nuevo (%d) no cabe en el viejo (%d)" % (len(new), len(old))); return 1
    d = bytearray(open(src, "rb").read())
    if d[:4] != b"\x7fELF" or d[4] != 2 or d[5] != 1:
        print("error: no es un ELF de 64 bits little-endian"); return 1

    e_phoff, = struct.unpack_from("<Q", d, 0x20)
    e_shoff, = struct.unpack_from("<Q", d, 0x28)
    e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx = struct.unpack_from("<HHHHH", d, 0x36)

    loads, dyn_off, dyn_sz = [], None, None
    for i in range(e_phnum):
        p_type, p_flags, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_align = \
            struct.unpack_from("<IIQQQQQQ", d, e_phoff + i * e_phentsize)
        if p_type == 1: loads.append((p_vaddr, p_offset, p_filesz))
        if p_type == 2: dyn_off, dyn_sz = p_offset, p_filesz
    if dyn_off is None:
        print("error: sin PT_DYNAMIC"); return 1

    def v2o(v):
        for va, off, sz in loads:
            if va <= v < va + sz: return off + v - va
        raise SystemExit("error: direccion fuera de los segmentos")

    strtab = strsz = None
    needed = []      # (posicion de la entrada en el archivo, offset de la cadena)
    other_str_refs = []   # entradas que tambien apuntan a .dynstr (SONAME, RUNPATH...)
    pos = dyn_off
    while pos < dyn_off + dyn_sz:
        tag, val = struct.unpack_from("<qQ", d, pos)
        if tag == 0: break
        if tag == 5: strtab = v2o(val)
        if tag == 10: strsz = val
        if tag == 1: needed.append((pos, val))
        if tag in (14, 15, 29): other_str_refs.append(val)   # SONAME, RPATH, RUNPATH
        pos += 16
    if strtab is None: print("error: sin DT_STRTAB"); return 1

    def cstr(off):
        end = d.index(b"\0", strtab + off)
        return bytes(d[strtab + off:end])

    names = [(p, o, cstr(o)) for p, o in needed]
    if any(n == new for _, _, n in names):
        shutil.copyfile(src, dst)
        print("ya estaba: %s ya es dependencia; copiado sin cambios" % new.decode()); return 0
    hit = [(p, o, n) for p, o, n in names if n == old]
    if not hit:
        print("error: %s no es dependencia. Dependencias: %s" % (old.decode(), [n.decode() for _, _, n in names])); return 1
    ent_pos, str_off, _ = hit[0]

    # seguridad: nadie mas debe apuntar a esos bytes (simbolos, versiones, otras entradas)
    lo, hi = str_off, str_off + len(old) + 1
    refs = [o for p, o, n in names if p != ent_pos] + other_str_refs
    # tabla de simbolos dinamicos, si hay cabeceras de seccion
    if e_shoff:
        secs = []
        for i in range(e_shnum):
            sh_name, sh_type, sh_flags, sh_addr, sh_off, sh_size, sh_link, sh_info, sh_align, sh_entsize = \
                struct.unpack_from("<IIQQQQIIQQ", d, e_shoff + i * e_shentsize)
            secs.append((sh_type, sh_off, sh_size, sh_entsize))
        for t, so, ss, es in secs:
            if t == 11:   # SHT_DYNSYM
                for k in range(ss // 24):
                    refs.append(struct.unpack_from("<I", d, so + k * 24)[0])
            if t == 0x6ffffffe:  # SHT_GNU_verneed
                q = so
                while True:
                    vn_version, vn_cnt, vn_file, vn_aux, vn_next = struct.unpack_from("<HHIII", d, q)
                    refs.append(vn_file)
                    a = q + vn_aux
                    for _ in range(vn_cnt):
                        _h, _f, _o, vna_name, vna_next = struct.unpack_from("<IHHII", d, a)
                        refs.append(vna_name)
                        if not vna_next: break
                        a += vna_next
                    if not vn_next: break
                    q += vn_next
    clash = [r for r in refs if lo <= r < hi]
    if clash:
        print("error: otras referencias apuntan a esa cadena (%s); no es seguro cambiarla" % clash[:3]); return 1

    before = bytes(d)
    d[strtab + str_off:strtab + str_off + len(new) + 1] = new + b"\0"
    # el resto del nombre viejo queda tras el NUL: se limpia para no dejar basura
    for k in range(len(new) + 1, len(old) + 1): d[strtab + str_off + k] = 0
    open(dst, "wb").write(d)
    changed = sum(1 for a, b in zip(before, d) if a != b)
    print("ok: %s -> %s (%d bytes cambiados, tamano igual: %s)" % (old.decode(), new.decode(), changed, len(before) == len(d)))
    return 0

sys.exit(main())
