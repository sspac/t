/*
 * frame_hook.c - dispara callbacks desde una funcion por-frame del port.
 *
 * libisaacport.so llama a sus funciones shim_*_between_frames (todas void f(void))
 * una vez por frame presentado, a traves de la PLT. Aqui se localiza el slot
 * GOT de una de ellas y se reemplaza por un envoltorio que llama a la original
 * y luego dispara los callbacks. Solo se modifica un puntero de datos: no se
 * genera ni se parchea codigo maquina.
 */
#define _GNU_SOURCE
#include "isaaclua.h"

#include <elf.h>
#include <link.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#define CB_POST_UPDATE 1
#define CB_POST_RENDER 2

extern void il_hooks_tick(void);

#ifndef R_X86_64_JUMP_SLOT
#define R_X86_64_JUMP_SLOT 7
#endif
#ifndef R_AARCH64_JUMP_SLOT
#define R_AARCH64_JUMP_SLOT 1026
#endif

typedef void (*void_fn)(void);

static void_fn  g_orig = NULL;       /* funcion original del port (acceso atomico) */
static void   **g_slot = NULL;       /* slot GOT parcheado */
static void    *g_wrapper_installed = NULL;
static unsigned g_frames = 0;        /* solo lo toca el hilo que llama al envoltorio */
static int      g_divisor = 2;       /* acceso atomico */

static void log_line(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
extern void il_log_ext(const char *line); /* definido en isaaclua.c */

#include <stdarg.h>
static void log_line(const char *fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    il_log_ext(buf);
}

int isaaclua_cb_post_update(void) { return CB_POST_UPDATE; }

ISAACLUA_API void isaaclua_set_update_divisor(int n) { __atomic_store_n(&g_divisor, n < 0 ? 0 : n, __ATOMIC_RELAXED); }

static void frame_wrapper(void) {
    int div = __atomic_load_n(&g_divisor, __ATOMIC_RELAXED);
    g_frames++;
    if (div > 0 && (g_frames % (unsigned)div) == 0) {
        isaaclua_note_update();
        isaaclua_fire(CB_POST_UPDATE, IL_NO_PARAM, 0, NULL, NULL);
    }
    /* copia local: remove_frame_hook puede poner g_orig a NULL en otro hilo */
    void_fn orig = (void_fn)__atomic_load_n((void **)&g_orig, __ATOMIC_ACQUIRE);
    if (orig) orig();
    isaaclua_fire(CB_POST_RENDER, IL_NO_PARAM, 0, NULL, NULL);
    il_hooks_tick();   /* enganches dentro de isaac.arm64 (ver hooks.c) */
}

/* ---- localizar la biblioteca y su tabla de relocaciones PLT ---------------- */
typedef struct {
    const char *lib;
    ElfW(Addr)  bias;
    ElfW(Dyn)  *dyn;
} FindCtx;

static int find_cb(struct dl_phdr_info *info, size_t size, void *data) {
    (void)size;
    FindCtx *c = (FindCtx *)data;
    if (!info->dlpi_name || !strstr(info->dlpi_name, c->lib)) return 0;
    for (int i = 0; i < info->dlpi_phnum; i++) {
        if (info->dlpi_phdr[i].p_type == PT_DYNAMIC) {
            c->bias = info->dlpi_addr;
            c->dyn  = (ElfW(Dyn) *)(info->dlpi_addr + info->dlpi_phdr[i].p_vaddr);
            return 1;
        }
    }
    return 0;
}

/* d_ptr: bionic deja direcciones sin reubicar; glibc las reubica en sitio */
static ElfW(Addr) fix(ElfW(Addr) p, ElfW(Addr) bias) { return p < bias ? p + bias : p; }

/* permisos actuales de la pagina (de /proc/self/maps) para restaurarlos */
static int page_prot(uintptr_t addr) {
    FILE *f = fopen("/proc/self/maps", "r");
    if (!f) return PROT_READ;
    char line[512];
    int prot = PROT_READ;
    while (fgets(line, sizeof line, f)) {
        unsigned long lo, hi; char perms[8];
        if (sscanf(line, "%lx-%lx %7s", &lo, &hi, perms) == 3 && addr >= lo && addr < hi) {
            prot = 0;
            if (perms[0] == 'r') prot |= PROT_READ;
            if (perms[1] == 'w') prot |= PROT_WRITE;
            if (perms[2] == 'x') prot |= PROT_EXEC;
            break;
        }
    }
    fclose(f);
    return prot;
}

static void **find_slot(const char *lib, const char *symbol, int verbose) {
    FindCtx c = { lib, 0, NULL };
    if (!dl_iterate_phdr(find_cb, &c) || !c.dyn) {
        if (verbose) log_line("enganche: no se encontro %s cargada", lib);
        return NULL;
    }
    ElfW(Rela) *jmprel = NULL; size_t pltrelsz = 0;
    ElfW(Sym) *symtab = NULL; const char *strtab = NULL;
    for (ElfW(Dyn) *d = c.dyn; d->d_tag != DT_NULL; d++) {
        switch (d->d_tag) {
        case DT_JMPREL:   jmprel   = (ElfW(Rela) *)fix(d->d_un.d_ptr, c.bias); break;
        case DT_PLTRELSZ: pltrelsz = d->d_un.d_val; break;
        case DT_SYMTAB:   symtab   = (ElfW(Sym) *)fix(d->d_un.d_ptr, c.bias); break;
        case DT_STRTAB:   strtab   = (const char *)fix(d->d_un.d_ptr, c.bias); break;
        default: break;
        }
    }
    if (!jmprel || !symtab || !strtab) { if (verbose) log_line("enganche: %s sin tabla PLT", lib); return NULL; }
    size_t n = pltrelsz / sizeof(ElfW(Rela));
    for (size_t i = 0; i < n; i++) {
        unsigned type = ELF64_R_TYPE(jmprel[i].r_info);
        if (type != R_X86_64_JUMP_SLOT && type != R_AARCH64_JUMP_SLOT) continue;
        const char *name = strtab + symtab[ELF64_R_SYM(jmprel[i].r_info)].st_name;
        if (strcmp(name, symbol) == 0) return (void **)(c.bias + jmprel[i].r_offset);
    }
    if (verbose) log_line("enganche: %s no esta en la PLT de %s", symbol, lib);
    return NULL;
}

static int write_slot(void **slot, void *value) {
    uintptr_t pg = (uintptr_t)sysconf(_SC_PAGESIZE);
    uintptr_t page = (uintptr_t)slot & ~(pg - 1);
    int old = page_prot((uintptr_t)slot);
    if (mprotect((void *)page, pg, PROT_READ | PROT_WRITE) != 0) return -1;
    __atomic_store_n(slot, value, __ATOMIC_RELEASE);
    mprotect((void *)page, pg, old);
    return 0;
}

static pthread_mutex_t g_mu = PTHREAD_MUTEX_INITIALIZER;

static int install_impl(const char *lib, const char *symbol, int verbose) {
    pthread_mutex_lock(&g_mu);
    int rc = 0;
    if (g_slot) goto out; /* ya instalado */
    if (!lib) lib = "libisaacport.so";
    if (!symbol) symbol = "shim_items_between_frames";
    void **slot = find_slot(lib, symbol, verbose);
    if (!slot) { rc = -1; goto out; }
    void *orig = *slot;
    if (!orig) { if (verbose) log_line("enganche: el slot de %s esta vacio", symbol); rc = -2; goto out; }
    __atomic_store_n((void **)&g_orig, orig, __ATOMIC_RELEASE);
    if (write_slot(slot, (void *)frame_wrapper) != 0) {
        if (verbose) log_line("enganche: no se pudo escribir el slot de %s", symbol);
        __atomic_store_n((void **)&g_orig, NULL, __ATOMIC_RELEASE); rc = -3; goto out;
    }
    g_slot = slot;
    g_wrapper_installed = (void *)frame_wrapper;
    log_line("enganche por frame instalado en %s (update cada %d frames)", symbol, g_divisor);
out:
    pthread_mutex_unlock(&g_mu);
    return rc;
}

ISAACLUA_API int isaaclua_install_frame_hook(const char *lib, const char *symbol) {
    return install_impl(lib, symbol, 1);
}

/* ---- version con reintentos: sirve si libaaclua se carga ANTES que libisaacport ---- */
typedef struct { char lib[128]; char sym[128]; int timeout_ms; } AsyncCtx;

static void *async_main(void *arg) {
    AsyncCtx c = *(AsyncCtx *)arg;
    free(arg);
    for (int waited = 0; waited <= c.timeout_ms; waited += 50) {
        if (install_impl(c.lib, c.sym, 0) == 0) return NULL;
        usleep(50 * 1000);
    }
    log_line("enganche: %s sigue sin aparecer tras %d ms; me rindo", c.lib, c.timeout_ms);
    return NULL;
}

ISAACLUA_API int isaaclua_install_frame_hook_async(const char *lib, const char *symbol, int timeout_ms) {
    if (install_impl(lib, symbol, 0) == 0) return 0;   /* ya estaba lista la biblioteca */
    AsyncCtx *c = (AsyncCtx *)calloc(1, sizeof *c);
    if (!c) return -1;
    snprintf(c->lib, sizeof c->lib, "%s", lib ? lib : "libisaacport.so");
    snprintf(c->sym, sizeof c->sym, "%s", symbol ? symbol : "shim_items_between_frames");
    c->timeout_ms = timeout_ms > 0 ? timeout_ms : 60000;
    char libname[128]; int tmo = c->timeout_ms;
    snprintf(libname, sizeof libname, "%s", c->lib);     /* copia: el hilo libera 'c' */
    pthread_t th;
    if (pthread_create(&th, NULL, async_main, c) != 0) { free(c); return -1; }
    pthread_detach(th);
    log_line("enganche: esperando a que cargue %s (hasta %d ms)", libname, tmo);
    return 1;                                           /* pendiente */
}

ISAACLUA_API void isaaclua_remove_frame_hook(void) {
    pthread_mutex_lock(&g_mu);
    void *orig = __atomic_load_n((void **)&g_orig, __ATOMIC_ACQUIRE);
    if (g_slot && orig) write_slot(g_slot, orig);   /* primero restaurar el slot */
    g_slot = NULL; g_wrapper_installed = NULL;
    /* g_orig se deja intacto: un hilo que ya estaba dentro del envoltorio aun lo necesita */
    pthread_mutex_unlock(&g_mu);
}
