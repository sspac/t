/*
 * autoboot.c - arranque automatico al cargar libisaaclua.so (solo Android).
 * Se compila con -DISAACLUA_AUTOBOOT. Se dispara con System.loadLibrary("isaaclua")
 * (ver LEEME.md, paso de smali), DESPUES de cargar libisaacport.so.
 */
#ifdef ISAACLUA_AUTOBOOT
#include "isaaclua.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

extern void il_log_ext(const char *line);

static int dir_exists(const char *p) { struct stat st; return stat(p, &st) == 0 && S_ISDIR(st.st_mode); }

__attribute__((constructor)) static void il_autoboot(void) {
    char log[1000];
    if (getenv("ISAACLUA_DISABLE")) return;

    /* nombre del paquete = primera cadena de /proc/self/cmdline (sin ":proceso") */
    char pkg[256] = {0};
    FILE *f = fopen("/proc/self/cmdline", "rb");
    if (f) { size_t n = fread(pkg, 1, sizeof pkg - 1, f); pkg[n] = 0; fclose(f); }
    char *colon = strchr(pkg, ':'); if (colon) *colon = 0;
    if (!pkg[0]) { il_log_ext("autoboot: sin nombre de paquete"); return; }

    /* La ruta exacta de la carpeta de mods depende del port: probamos las habituales
     * y tambien ISAACLUA_BASE si se define (carpeta que contiene "mods/"). */
    char base[600] = {0};
    const char *env = getenv("ISAACLUA_BASE");
    char cand[8][600];
    /* paquete del port: com.tboi.modded1 (carpeta Android/media/<paquete>/mods).
     * tboi.reborthmodetc se mantiene como alternativa por si la carpeta se llama asi. */
    snprintf(cand[0], sizeof cand[0], "/storage/emulated/0/Android/media/com.tboi.modded1");
    snprintf(cand[1], sizeof cand[1], "/sdcard/Android/media/com.tboi.modded1");
    snprintf(cand[2], sizeof cand[2], "/storage/emulated/0/Android/media/tboi.reborthmodetc");
    snprintf(cand[3], sizeof cand[3], "/storage/emulated/0/Android/media/%.200s", pkg);
    snprintf(cand[4], sizeof cand[4], "/storage/emulated/0/Android/data/%.200s/files", pkg);
    snprintf(cand[5], sizeof cand[5], "/data/user/0/%.200s/files", pkg);
    snprintf(cand[6], sizeof cand[6], "/data/data/%.200s/files", pkg);
    snprintf(cand[7], sizeof cand[7], "/sdcard/Android/media/tboi.reborthmodetc");
    if (env && *env) snprintf(base, sizeof base, "%s", env);
    for (int i = 0; !base[0] && i < 8; i++) {
        char probe[1300]; snprintf(probe, sizeof probe, "%.590s/mods", cand[i]);
        if (dir_exists(probe)) snprintf(base, sizeof base, "%.590s", cand[i]);
    }
    if (!base[0]) {
        snprintf(log, sizeof log, "autoboot: no hay carpeta mods/ en las rutas de %s (usa ISAACLUA_BASE)", pkg);
        il_log_ext(log);
        return;
    }
    char mods[700], saves[700];
    snprintf(mods, sizeof mods, "%s/mods", base);
    snprintf(saves, sizeof saves, "%s/lua", base);
    snprintf(log, sizeof log, "autoboot: mods=%s", mods);
    il_log_ext(log);

    isaaclua_boot(NULL, mods, saves, NULL);   /* scripts embebidos */
    isaaclua_install_frame_hook_async(NULL, NULL, 60000); /* reintenta si libisaacport aun no carga */
}
#endif
