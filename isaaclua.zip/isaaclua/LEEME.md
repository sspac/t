# isaaclua — capa Lua 5.3 para el port de Isaac (paquete com.tboi.modded1)

Mods en Lua para el port, sin tocar el código del juego (`isaac.arm64`). Carga los `main.lua` de
`Android/media/com.tboi.modded1/mods/<mod>/` y dispara callbacks desde una función por-frame del port.

## Qué hay en este zip
- `apk_files/lib/arm64-v8a/libisaacport.so` — **tu `libisaacport.so` ya parcheado** (6 bytes: la
  dependencia `liblog.so` pasa a llamarse `libil.so`). Es el de tu zip `TBOI_1_77_modded_v6_0_1`
  (sha256 original `afa41beb…f4948`). Si tu APK usa otro `libisaacport.so`, no copies este: pásale
  `python3 tools/patch_needed.py ORIGINAL.so SALIDA.so` al tuyo.
- `libil.so` — **falta**: hay que compilarlo para arm64 (ver abajo). Es lo único que no puedo generar.
- `src/`, `scripts/`, `third_party/lua-5.3.3/` (Lua 5.3.3 sin modificar, MIT), `tools/`, `test/`.

## Instalación (3 comandos, sin editar smali ni el dex)
1. Compilar `libil.so`, una de dos:
   - **GitHub:** sube la carpeta a un repositorio, pestaña *Actions → build → Run workflow*, descarga el
     artefacto `libil` (`.github/workflows/build.yml` hace todo).
   - **Termux:** `pkg install clang`, luego `sh tools/build_android.sh`.
2. Con tu APK descomprimida: `sh tools/install_into_apk.sh CARPETA_APK libil.so`
   (copia `libil.so` y parchea `libisaacport.so`; o copia a mano los dos archivos de `apk_files/` + `libil.so`).
3. `sh tools/pack_apk.sh CARPETA_APK salida.apk` (zip + zipalign + firma; necesita `apksigner`/`zipalign`,
   en Termux `pkg install apksigner zipalign`). Sin firmar Android no lo instala.
**Las dos `.so` van juntas**: si `libil.so` falta, `libisaacport.so` no carga y el juego cierra al abrir.
Revisa `adb logcat -s isaaclua`: `autoboot: mods=...`, `isaaclua listo: N mod(s)`, `enganche por frame instalado`.

## Cómo engancha
`libisaacport.so` presenta cada frame llamando en orden a `shim_*_between_frames` (`void f(void)`, por PLT).
`libil.so` cambia el puntero GOT de `shim_items_between_frames` por un envoltorio que llama a la original y
dispara los callbacks. Solo se modifica un puntero de datos; no se parchea código máquina. Si `libil.so`
carga antes que `libisaacport` (es lo normal con este parche), el enganche reintenta cada 50 ms hasta 60 s.

## Callbacks
| callback | origen |
|---|---|
| `MC_POST_RENDER` | real: una vez por frame presentado |
| `MC_POST_UPDATE` | **aproximado**: cada 2 frames de render (supone 60 fps / 30 ups) |
| los demás | **por calibrar** (ver abajo): enganches dentro de `isaac.arm64` |

### Enganches dentro de `isaac.arm64` (hooks.c) — sin calibrar
Misma técnica que los parches v33 del port: al primer frame, `libil.so` escribe `b cueva` en la primera
instrucción de 30 funciones candidatas del juego. La cueva (en el relleno de ceros al final de `__TEXT`) solo
suma 1 a un contador y guarda `x0`/`x1` en un buzón de `libil.so`, ejecuta la instrucción desplazada y vuelve.
Cada frame `libil.so` lee los contadores y dispara los callbacks que tú hayas mapeado.
- Antes de tocar un sitio comprueba que su instrucción sea la original del binario y no dependa de PC;
  si no, lo omite y lo anota. Solo usa huecos de ceros de ≥256 bytes (no pisa tablas de otros parches).
- **Los 30 candidatos son hipótesis**: unos salen de las sondas del propio port (`HALLAZGOS_probes.md`),
  otros de funciones que contienen mensajes del juego ("Level::load_room…", "Entity TakeDamage…").
  Esas cadenas aparecen en varias funciones (hay copias o código incrustado), por eso hay 4 candidatos por mensaje.
- Un candidato equivocado **no cambia el juego**: solo dispararía el callback en momentos equivocados.
- **Por defecto no se dispara ningún callback desde ellos.** Se calibra así:
  1. Abre el juego y haz, con pausas de unos segundos: (a) quédate quieto 15 s, (b) cambia de sala,
     (c) recibe daño un enemigo, (d) usa el item activo, (e) empieza una partida nueva.
  2. Mira `Android/media/com.tboi.modded1/lua/hooks_log.txt` (se actualiza cada ~2 s): cuenta cada enganche.
     Un contador que sube 1 solo al cambiar de sala es el de `MC_POST_NEW_ROOM`; uno que sube ~30/s quieto es el update.
  3. Anota cuál subió en cada acción y pásamelo (o edita tú `hooks.cfg`, ver `hooks.cfg.example`).

## API de mods
`RegisterMod`, `AddCallback/AddPriorityCallback/RemoveCallback` (filtro por parámetro, `CallbackPriority`),
`SaveData/LoadData/HasData/RemoveData` (en `Android/media/com.tboi.modded1/lua/`), `Isaac.DebugString/
ConsoleOutput/GetFrameCount/GetTime`, `print`, `include()`, `require()` en la carpeta del mod, `Game():GetFrameCount()`.
Carpetas con `disable.it` se saltan. Un error en un mod o callback se registra y no afecta al resto.
Protecciones: sin `io`/procesos/código nativo, tope de 192 MB, límite de instrucciones por llamada, mutex.

## Pruebas hechas (todas en PC x86; **nada en Android/arm64**)
Núcleo 30/30; enganche GOT 17/17 con una biblioteca simulada (incluye carga tardía); enganches en el binario 13/13
con una imagen falsa, más una **emulación** de las 30 cuevas arm64 generadas (suman el contador, guardan x0/x1,
conservan la instrucción desplazada y vuelven a sitio+4); todo limpio con ASan, UBSan y ThreadSanitizer. El parche ELF se verificó con `readelf` (6 bytes distintos, mismo tamaño, 1245 símbolos
intactos). Sin verificar: que el linker de Android acepte la dependencia sustituida, y la ruta de mods real.
Tras `adb logcat` sabrás en qué paso falla, si falla.
